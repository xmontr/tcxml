

chrome.runtime.onConnect.addListener(function(port) {
   
    port.onMessage.addListener(function(msg) {
        switch(msg.action){
        case "deleteAllCookies": deleteCookies();port.postMessage({ret: "cookie are deleted",action:msg.action}); break;
		case "clearLocalStorage": clearLocalStorage();port.postMessage({ret: "local storage is deleted",action:msg.action}); break;
        default: port.postMessage({ret: "unknown action",action:msg.action});

    }



    });
  });