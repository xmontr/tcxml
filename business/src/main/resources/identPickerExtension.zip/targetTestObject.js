/*** js that manage the data around a testobject : xpath , position, auto-name , fallbackName **/


var TargetTestObject = function( domObject) { // constructor

this.domObject = domObject ;
this.predicats = [];
this.position =1 ;
this.tagname = this.domObject.tagName.toLowerCase();
this.autoName="";
this.fallBackName="";
this.xpath="";
this.computePredicats();
this.computePosition();
this.computeXpath();
this.computeName();


}

	TargetTestObject.prototype.computeXpath = function ( ) { // compute the full xpath with position
	var ret = this.getXpathWithoutPosition();
	ret += "[" + this.position + "]" ; 
	this.xpath = ret ;	
	}




	TargetTestObject.prototype.computePredicats = function ( ) { // determine the relvant predicats for the testobject
	
			this.addPredicat("name") ;	
			this.addPredicat("type") ;
		this.addPredicat("value") ;
         this.addTextPredicat();
			this.addPredicat("alt") ;
			this.addPredicat("title") ;
 
			

		}
		
	
	
	
		TargetTestObject.prototype.computeName = function ( ) { // determine the autoname and fallback name for domObject
	
		switch (this.tagname) {
		case "select" :	
		
		break;
		case "input":
	
		
		break;		
		case "a":
		
		break;
		
		case "img":


		break;
		default:
 
			

		}
		
	}
	
	
	
	
	
	
	
	
		TargetTestObject.prototype.computePosition = function ( ) { // determine the position according a basic xpath based on the tagname and the predicats
		var xpath = this.getXpathWithoutPosition();
				var 			foundedobject ,
	
			theresult = this.domObject.ownerDocument.evaluate(
				xpath, 
				this.domObject.ownerDocument, 
				null, 
				XPathResult.ORDERED_NODE_ITERATOR_TYPE, 
				null
			);
			
			console.log(" computeposition : relusttype is " +theresult.resultType  );
			
			
			foundedobject = theresult.iterateNext();	
			console.log("founded=" + foundedobject );
	while(foundedobject ) {
		
		if( foundedobject === this.domObject ) {
			console.log("trouver  a position " + this.position   ) ;
			break;
			}		
		foundedobject = theresult.iterateNext();
		this.position = this.position +1 ;
	}
	
	

		
	}
	
	
	
	






TargetTestObject.prototype.addPredicat = function  ( predname  ) {// add the predicat if value exist
var predval = this.domObject.getAttribute(predname);
if( predval != null && predval != "" ) {
			var thePred = new Object();
		thePred.name= predname;
		thePred.value= predval;
		this.predicats.push(thePred);
	
}

	
	}
	
	
	TargetTestObject.prototype.addTextPredicat = function  (  ) {// add the text()  predicat if text() value exist
var predval = this.getTextForObject();
if( predval != null && predval != "" && predval.trim().length != 0 ) {
			var thePred = new Object();
		thePred.name= "text()";
		thePred.value= predval;
		this.predicats.push(thePred);
	}
	
	}
	
	
	
	TargetTestObject.prototype.getTextForObject = function  (  ) {  // get the text() for the dome object
	this.domObject.normalize();
				var xpathResult =this.domObject.ownerDocument.evaluate(
				"text()", 
				this.domObject, 
				null, 
				XPathResult.STRING_TYPE, 
				null
			);
			var ret =xpathResult.stringValue;			
	return ret;
	

	}
	
	
	TargetTestObject.prototype.generatePredicat = function () { // generate the string fpr the xpath predicat
	var ret="",
		index=0;
		if (this.predicats.length == 0  ) return ret;
		ret = " [ @" + this.predicats[0].name + " = \"" +    this.predicats[0].value +"\"" ;		
		for( index=1; index < this.predicats.length ; index++ ) {
			ret = ret + " and @" + this.predicats[index].name + " = \"" +    this.predicats[index].value +"\"" ;	
		}
		ret = ret + " ] " ;
	return ret;
	}
	
	
	TargetTestObject.prototype.getXpathWithoutPosition = function ( ) { // generate the xpath for finding the element without the position
	var ret =  "//" + this.tagname +this.generatePredicat();	
	return ret;	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	