var port = chrome.runtime.connect();



var Ident = function() { // constructor
console.log("building Ident object");
		  this.hoverBox = document.createElement("div");
		  this.hoverBox.setAttribute("id", "identBox");
		  
		   this.selectionStorage=document.createElement("p");
		    this.selectionStorage.setAttribute("id","identStorage");
		   this.selectionStorage.style.display = "none";
		   this.selectionText = document.createTextNode("");
		   this.selectionStorage.appendChild(this.selectionText); 
		   document.body.appendChild(this.selectionStorage);
		    this.selectionStorage.setAttribute("status", "stop");
}	

var theIdent = new Ident() ;


var  manageSelection = function (e){ // called when the user click to select the chosen element
	 const target = e.target;
	 
	 var targetTo = new TargetTestObject(target);
	 var theSelection= {};
	 
	 theSelection.xpath = targetTo.xpath;
	 theSelection.autoName=targetTo.autoName;
	 theSelection.fallBackName=targetTo.fallBackName;
	 
	 var newTextNode = document.createTextNode(JSON.stringify(theSelection));
	  this.selectionStorage.replaceChild(newTextNode, this.selectionText);
	  this.selectionText=newTextNode;
	 
	 
	 console.log("Ident - the selection is xpath stored: " + JSON.stringify(theSelection));
	 this.selectionStorage.setAttribute("status", "done");
	 e.preventDefault();
	 e.stopPropagation();
	 this.stopSelection();
	 
}

var  bmanageSelection = manageSelection.bind(theIdent);


 var manageKeyboard = function (e){ // manage the <ESC> key press to leave the selector
  
 if(e.keyCode === 27 ){
	 console.log( "Ident catch <ESC> press" );
	
	 this.stopSelection();
	  this.hoverBox.setAttribute("status", "canceled");
	 
 }





 }
	
bmanagekeyboard	= manageKeyboard.bind(theIdent);
	


theIdent.startSelection = function() {
	console.log( "Ident start selection" );
	
this.selectionStorage.setAttribute("status", "run");

this.hoverBox.style.position = "absolute";
// change to whatever highlight color you want
this.hoverBox.style.background = "lightblue";
// avoid blocking the hovered element and its surroundings
this.hoverBox.style.zIndex = "-9999"
	
	document.body.appendChild(this.hoverBox);
document.addEventListener("mouseover", (e) => {
  const target = e.target;
  const targetOffset = target.getBoundingClientRect();
  const targetHeight = targetOffset.height;
  const targetWidth = targetOffset.width;
  // add a border around hover box
  const boxBorder = 5;
  this.hoverBox.style.width = targetWidth + boxBorder * 2 + "px";
 
  this.hoverBox.style.height = targetHeight + boxBorder * 2 + "px";
  // need scrollX and scrollY to account for scrolling
  this.hoverBox.style.top = targetOffset.top + window.scrollY - boxBorder + "px";
  this.hoverBox.style.left = targetOffset.left + window.scrollX - boxBorder + "px";
});


document.addEventListener("click", bmanageSelection ,true);
document.addEventListener("keydown", bmanagekeyboard ,true);
	
	
	
	
	
}


theIdent.stopSelection = function() { // end the selection 
	console.log( "Ident stop selection" );
	document.body.removeChild(this.hoverBox)
	
	document.removeEventListener("click", bmanageSelection , true);
	document.removeEventListener("keydown", bmanagekeyboard ,true);
	
	
	
	
}


theIdent.getSelection = function() { // retrieve the selection
	
	
	
	
	
}

theIdent.manageMessage = function (mess) {
	    console.log( "manage message" + mess.action );
	
	switch(mess.action) {
	case "start":this.startSelection(); break;
case "stop": this.stopSelection(); break;	
	fefault: console.log("unknown action" +mess.action);	
		
	}
	
	
}


	


window.addEventListener("message", function(event) {
    // We only accept messages from ourselves
    if (event.source != window)
      return;
  
 
      console.log("Content script received: " + event.data);
	  theIdent.manageMessage(event.data)
      //port.postMessage(event.data);
	  
	  
    
  }, false);

port.onMessage.addListener(function(msg) {

    console.log( "from extension:action=" + msg.action + " ret=" + msg.ret);
  });
  
  
  
  
  

