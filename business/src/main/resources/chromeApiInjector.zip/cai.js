var callBackDelete = function(details){
if(details == null){

console.log( "fail to delete cookie" + chrome.runtime.lastError.message );

}else {

console.log("cookie sucessfully deleted" + details.name);

}


}


var deleteCookies=function() {

    chrome.cookies.getAll({}, function(cookies) {
        for(var i=0; i<cookies.length;i++) {
          console.log(cookies[i]);
          var theurl = "http://" + cookies[i].domain  + cookies[i].path  ; 
console.log( "cookie url to remove:" + theurl);


          if(cookies[i].secure) {
            chrome.cookies.remove({url: "https://" + cookies[i].domain  + cookies[i].path, name: cookies[i].name},callBackDelete);

          } else {

            chrome.cookies.remove({url: "http://" + cookies[i].domain  + cookies[i].path, name: cookies[i].name},callBackDelete);   
          }
    
          
        }
      });


}


chrome.runtime.onConnect.addListener(function(port) {
   
    port.onMessage.addListener(function(msg) {
        switch(msg.action){
        case "deleteAllCookies": deleteCookies();port.postMessage({ret: "cookie are deleted",action:msg.action}); break;
        default: port.postMessage({ret: "unknown action",action:msg.action});

    }



    });
  });