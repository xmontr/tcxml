var deleteCookies=function() {

    chrome.cookies.getAll({}, function(cookies) {
        for(var i=0; i<cookies.length;i++) {
          console.log(cookies[i]);

          if(cookies[i].secure) {
            chrome.cookies.remove({url: "https://" + cookies[i].domain  + cookies[i].path, name: cookies[i].name});

          } else {

            chrome.cookies.remove({url: "http://" + cookies[i].domain  + cookies[i].path, name: cookies[i].name});   
          }
    
          
        }
      });


}


chrome.runtime.onConnect.addListener(function(port) {
   
    port.onMessage.addListener(function(msg) {
        switch(msg.action){
        case "deleteAllCookies": deleteCookies;port.postMessage({ret: "cookie are deleted",action:msg.action}); break;
        default: port.postMessage({ret: "unknown action",action:msg.action});

    }



    });
  });