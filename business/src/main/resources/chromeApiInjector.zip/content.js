var port = chrome.runtime.connect();
window.addEventListener("message", function(event) {
    // We only accept messages from ourselves
    if (event.source != window)
      return;
  
 
      console.log("Content script received: " + event.data);
      port.postMessage(event.data);
    
  }, false);

port.onMessage.addListener(function(msg) {

    console.log( "from extension:action=" + msg.action + " ret=" + msg.ret);
  });

